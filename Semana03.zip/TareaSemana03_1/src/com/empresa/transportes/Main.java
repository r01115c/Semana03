package com.empresa.transportes;

public class Main {

    public static void main(String[] args) {
        TransporteForm interfaz = new TransporteForm();
        interfaz.setVisible(true);
    }
    
}
