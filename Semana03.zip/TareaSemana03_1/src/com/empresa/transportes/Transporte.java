package com.empresa.transportes;

public class Transporte {
    private final double PRECIO_PASAJES = 37.5;

    public double calcularImporte(int cantidadPasajes) {
        return cantidadPasajes * PRECIO_PASAJES;
    }

    public double calcularDescuento(int cantidadPasajes, double importe) {
        if (cantidadPasajes >= 15) {
            return importe * 0.08; // 8% de descuento
        } else {
            return importe * 0.05; // 5% de descuento
        }
    }

    public double calcularImporteFinal(double importe, double descuento) {
        return importe - descuento;
    }

    public int calcularCaramelos(double importeFinal) {
        return importeFinal > 200 ? (int) (importeFinal / PRECIO_PASAJES * 2) : 0;
    }
}

