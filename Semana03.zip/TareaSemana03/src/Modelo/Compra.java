package Modelo;

public class Compra {
    private double precioPorDocena;
    private int cantidadDocenas;
    private double importeCompra;
    private double importeDescuento;
    private double importeAPagar;
    private int cantidadLapiceros;

    // Getters y Setters
    public double getPrecioPorDocena() {
        return precioPorDocena;
    }

    public void setPrecioPorDocena(double precioPorDocena) {
        this.precioPorDocena = precioPorDocena;
    }

    public int getCantidadDocenas() {
        return cantidadDocenas;
    }

    public void setCantidadDocenas(int cantidadDocenas) {
        this.cantidadDocenas = cantidadDocenas;
    }

    public double getImporteCompra() {
        return importeCompra;
    }

    public void setImporteCompra(double importeCompra) {
        this.importeCompra = importeCompra;
    }

    public double getImporteDescuento() {
        return importeDescuento;
    }

    public void setImporteDescuento(double importeDescuento) {
        this.importeDescuento = importeDescuento;
    }

    public double getImporteAPagar() {
        return importeAPagar;
    }

    public void setImporteAPagar(double importeAPagar) {
        this.importeAPagar = importeAPagar;
    }

    public int getCantidadLapiceros() {
        return cantidadLapiceros;
    }

    public void setCantidadLapiceros(int cantidadLapiceros) {
        this.cantidadLapiceros = cantidadLapiceros;
    }

}

