package Service;

import Modelo.Compra;

public class CompraService {

    public void calcular(Compra compra) {
        // Calcular el importe de la compra
        double importeCompra = compra.getPrecioPorDocena() * compra.getCantidadDocenas();
        compra.setImporteCompra(importeCompra);

        // Calcular el descuento
        double descuento = 0.0;
        if (compra.getCantidadDocenas() > 10) {
            descuento = importeCompra * 0.15; // 15% de descuento
        } else if (compra.getCantidadDocenas() > 5) {
            descuento = importeCompra * 0.10; // 10% de descuento
        }
        compra.setImporteDescuento(descuento);

        // Calcular el importe a pagar
        double importeAPagar = importeCompra - descuento;
        compra.setImporteAPagar(importeAPagar);

        // Calcular la cantidad de lapiceros de obsequio
        int lapiceros;
        if (compra.getCantidadDocenas() > 10) {
            lapiceros = 3;
        } else if (compra.getCantidadDocenas() > 5) {
            lapiceros = 2;
        } else {
            lapiceros = 1;
        }
        compra.setCantidadLapiceros(lapiceros);
    }
}
